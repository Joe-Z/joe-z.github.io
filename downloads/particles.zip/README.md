###Information###
* The trackball-controls are entirely written by [egraether](https://github.com/egraether)
* This program was created with [OpenFrameworks](http://www.openframeworks.cc/) (V0.06) and
[MS Visual Studio 2008](http://www.microsoft.com/germany/visualstudio/products/default.aspx)

###Trackball-Controls###
* drag with left mouse-button: mouse to rotate scene
* drag with right mouse-button: translate scene
* drag with middle mouse-button: zoom in / out

###Keyboard-Controls###

* '1': Spark-Emitter
* '2': Ball-Emitter
* '3': "Tornado"-Emitter
* '4': Smoke-Emitter

* 'f': toggle fullscreen